import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-cart',
  templateUrl: './delete-cart.component.html',
  styleUrls: ['./delete-cart.component.css']
})
export class DeleteCartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
